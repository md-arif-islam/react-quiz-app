export default function Home() {
  return "Hello";
}
